// Log to console when the script is loaded
console.log('pixabay.js loaded');


const PIXABAY_API_KEY = '42776799-d11e3d974a55a5e5cab233af0';
// Define the URL for the Pixabay API request, including parameters for image type, orientation, and number of results per page
const PIXABAY_URL = `https://pixabay.com/api/?key=${PIXABAY_API_KEY}&image_type=photo&orientation=horizontal&per_page=30`;

/**
 * Dynamically creates HTML elements (posts) for each image fetched from the API.
 * @param {Array} images - An array of image objects retrieved from the Pixabay API.
 */
const makePosts = (images) => {
    // Clear any existing content in the blog column before adding new posts
    $('.blog-column').empty();
    // Iterate over each image object to create and append a new post element
    images.forEach(image => {
        // Define the HTML structure for each post using Bootstrap card components
        const element = `
            <div class="card" style="width: 18rem;">
                <img src="${image.webformatURL}" class="card-img-top" alt="${image.tags}">
                <div class="card-body">
                    <p class="card-text">${image.tags}</p>
                </div>
            </div>
        `;
        // Append the newly created card element to the blog column
        $('.blog-column').append(element);
    });
};

/**
 * Fetches image data from the Pixabay API and processes it to create posts.
 */
const getPictures = () => {
    // Use fetch to make a request to the Pixabay API URL
    fetch(PIXABAY_URL)
        .then(response => response.json()) // Parse the JSON response
        .then(data => makePosts(data.hits)) // Use the fetched images to create posts
        .catch(error => console.error('Error fetching data:', error)); // Log errors to the console
};

// Invoke the getPictures function to start the process
getPictures();
